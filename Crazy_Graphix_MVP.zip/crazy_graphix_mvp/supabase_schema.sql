-- Crazy Graphix starter schema for Supabase (production foundation only)
-- Review and test all policies before launch. Never expose service_role keys in a browser.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  contact text,
  created_at timestamptz not null default now()
);

create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null,
  reward_paisa integer not null check (reward_paisa >= 0),
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.submissions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  task_id uuid not null references public.tasks(id),
  proof_text text not null,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  reviewed_at timestamptz,
  created_at timestamptz not null default now(),
  unique(user_id, task_id)
);

create table if not exists public.wallet_transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  amount_paisa integer not null check (amount_paisa <> 0),
  kind text not null check (kind in ('task_reward','withdrawal_request','adjustment')),
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  reference_id uuid,
  created_at timestamptz not null default now()
);

create table if not exists public.withdrawal_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  method text not null check (method in ('jazzcash','easypaisa')),
  -- In production, store payment details only with appropriate safeguards/encryption.
  account_last4 text not null,
  amount_paisa integer not null check (amount_paisa > 0),
  status text not null default 'pending' check (status in ('pending','approved','rejected','paid')),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.tasks enable row level security;
alter table public.submissions enable row level security;
alter table public.wallet_transactions enable row level security;
alter table public.withdrawal_requests enable row level security;

-- Basic user-scoped policies. Admin actions must be implemented through trusted server-side
-- functions after adding a verified admin role; never trust a client-side "is_admin" flag.
create policy "Users read own profile" on public.profiles for select to authenticated using (auth.uid() = id);
create policy "Users insert own profile" on public.profiles for insert to authenticated with check (auth.uid() = id);
create policy "Users update own profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);
create policy "Authenticated users read active tasks" on public.tasks for select to authenticated using (is_active = true);
create policy "Users read own submissions" on public.submissions for select to authenticated using (auth.uid() = user_id);
create policy "Users create own submissions" on public.submissions for insert to authenticated with check (auth.uid() = user_id and status = 'pending');
create policy "Users read own wallet transactions" on public.wallet_transactions for select to authenticated using (auth.uid() = user_id);
create policy "Users read own withdrawals" on public.withdrawal_requests for select to authenticated using (auth.uid() = user_id);
create policy "Users request own withdrawals" on public.withdrawal_requests for insert to authenticated with check (auth.uid() = user_id and status = 'pending');

-- Important: balance changes and approval/rejection must happen atomically on a trusted backend.
-- Do not allow users to insert wallet credits or update task rewards from the client.
